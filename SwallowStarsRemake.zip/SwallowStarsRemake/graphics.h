#ifndef GRAPHICS_H
#define GRAPHICS_h

void setColor(int color);
void hideCursor();
void moveCursorToTop();
void startingScreen();
void endingScreen();
void printStatus();

#endif // GRAPHICS_H

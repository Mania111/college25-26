using namespace std;
#define WIN32_LEAN_AND_MEAN
#include <iostream>
#include <conio.h>
#include <windows.h>
#include <cstring>
#include <cctype>

#include "configload.h"
#include "gamelogic.h"
#include "graphics.h"
#include "main.h"

// ============================================= HELPER TRIMMING FUNCTION =============================================

// Function to trim unnecessary spaces and comments in "config.txt" in case those appear
void trim(char* str) {
    // Remove comments (# or // - both work)
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == '#') {
            str[i] = '\0';
            break;
        }
        if (str[i] == '/' && str[i + 1] == '/') {
            str[i] = '\0';
            break;
        }
    }

    // Trim trailing whitespace (spaces or tab)
    int len = strlen(str);
    while (len > 0 && isspace(static_cast<unsigned char>(str[len - 1]))) {
        str[len - 1] = '\0';
        len--;
    }
}

// ============================================= CONFIG LOAD FUNCTION =============================================

void loadConfig(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        printf("Could not open %s\n", filename);
        return;
    }
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        trim(line); // strip comments + trailing whitespace
        if (line[0] == '\0') continue; // skip empty lines

        char key[99];
        double value;

        if (sscanf(line, " %99[^=]=%lf", key, &value) == 2) {
            trim(key);
            if (strcmp(key, "BoardSizeX") == 0) BoardSizeX = value;
            else if (strcmp(key, "BoardSizeY") == 0) BoardSizeY = value;
            else if (strcmp(key, "starsToCatch") == 0) starsToCatch = value;
            else if (strcmp(key, "playerLifeForce") == 0) playerLifeForce = value;
            else if (strcmp(key, "starSpawnRateBase") == 0) starSpawnRateBase = value;
            else if (strcmp(key, "hunterSpawnRateBase") == 0) hunterSpawnRateBase = value;
            else if (strcmp(key, "minSpeed") == 0) minSpeed = value;
            else if (strcmp(key, "maxSpeed") == 0) maxSpeed = value;
            else if (strcmp(key, "hunterMaxWidth") == 0) hunterMaxWidth = value;
            else if (strcmp(key, "hunterMaxHeight") == 0) hunterMaxHeight = value;
            else if (strcmp(key, "timeLeft") == 0) timeLeft = value;
            else if (strcmp(key, "difficulty") == 0) difficulty = value;
        }
    }
    fclose(file);
}
// ============================================= END OF CONFIGLOAD.CPP =============================================

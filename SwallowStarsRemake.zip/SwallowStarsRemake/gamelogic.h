#ifndef GAMELOGIC_H
#define GAMELOGIC_H

void applyDifficulty(int difficulty);
void updateDifficultyRates();
void spawnStars();
void moveStars();
void checkIfStarCaught();
void spawnHunters();
void moveHunters();
void checkHunterCollisions();
void printBoard();
void saveScore(int score);
int findBestScore();

extern int finalScore;

#endif // GAMELOGIC_H

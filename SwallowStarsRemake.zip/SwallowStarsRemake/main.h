#ifndef MAIN_H
#define MAIN_H

// this header will also store global variables so they can be used by files other than main.cpp

extern int Px, Py;
extern int BoardSizeX, BoardSizeY;
extern int currentSpeed, minSpeed, maxSpeed;
extern int timer, timeLeft;

extern int starsToCatch;
extern int starsCaught;
extern int starSpeedMax;

extern int playerLifeForce;
extern int swallowFrame;
extern int level;
extern int difficulty;

extern double starSpawnRateBase;
extern double hunterSpawnRateBase;
extern int minSpeed, maxSpeed;
extern int hunterMaxWidth, hunterMaxHeight;


int main();

#endif

#define WIN32_LEAN_AND_MEAN
#include <iostream>
#include <conio.h>
#include <windows.h>

#include "gamelogic.h"
#include "graphics.h"
#include "main.h"

using namespace std;

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE); // console handle

// ============================================= COLOR FUNCTION =============================================

void setColor(int color) {
    SetConsoleTextAttribute(hConsole, color);
}

// ============================================= HIDE CURSOR =============================================

void hideCursor() {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;

    GetConsoleCursorInfo(hOut, &cursorInfo);
    cursorInfo.bVisible = FALSE;
    SetConsoleCursorInfo(hOut, &cursorInfo);
}

void moveCursorToTop() {
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD pos = {0, 0};
    SetConsoleCursorPosition(hOut, pos);
}

// ============================================= INTRO , OUTRO AND STATUS DISPLAY =============================================

void startingScreen() {
    string title[] = {
    R"( ____  _  _   __   __    __     __   _  _    ____  ____  __   ____  ____ )",
    R"(/ ___)/ )( \ / _\ (  )  (  )   /  \ / )( \  / ___)(_  _)/ _\ (  _ \/ ___))",
    R"(\___ \\ /\ //    \/ (_/\/ (_/\(  O )\ /\ /  \___ \  )( /    \ )   /\___ \)",
    R"((____/(_/\_)\_/\_/\____/\____/ \__/ (_/\_)  (____/ (__)\_/\_/(__\_)(____/)"
    };

    int numLines = sizeof(title) / sizeof(title[0]);
    for (int i = 0; i < numLines; i++) {
        cout << title[i] << endl;
    }
    cout << "           Press Any Key To Play";

    getch();
    system("cls");
}

// ---------------------------------------- GAME OVER SCREEN ----------------------------------------

void endingScreen() {
    system("cls");

    string endingTitle[] = {
        R"(  ___   __   _  _  ____     __   _  _  ____  ____ )",
        R"( / __) / _\ ( \/ )(  __)   /  \ / )( \(  __)(  _ \)",
        R"(( (_ \/    \/ \/ \ ) _)   (  O )\ \/ / ) _)  )   /)",
        R"( \___/\_/\_/\_)(_/(____)   \__/  \__/ (____)(__\_))"
    };

    int numLines = sizeof(endingTitle) / sizeof(endingTitle[0]);
    for (int i = 0; i < numLines; i++) {
        cout << endingTitle[i] << endl;
    }
    cout << "\n       Player Score: " << ((timeLeft-timer) * (playerLifeForce+starsCaught))*difficulty << endl;
    int currentBestScore = findBestScore();
    cout << "       BEST SCORE: " << currentBestScore << endl;
    cout << "         Thank you for Playing!\n";
    cout << "\n       Press any key to exit...";
    getch();
}

// ---------------------------------------- STATUS ----------------------------------------

void printStatus() {
    setColor(7); // default grey
    cout << "----------------";
    setColor(3); // aqua
    cout << " STATUS ";
    setColor(7);
    cout << "----------------" << endl;

    setColor(15); // bright white
    cout << "Speed | Level | Time | Stars | Life Force" << endl;

    cout << "  ";
    setColor(12); // red
    cout << currentSpeed << "       ";
    setColor(14); // yellow
    cout << level << "     ";
    setColor(10); // green
    cout << timer <<"/"<< timeLeft << "    ";
    setColor(11); // light cyan
    cout << starsCaught << "/" << starsToCatch << "        ";
    setColor(9); // default grey
    cout << playerLifeForce << " " << endl;

    setColor(7);
    cout << "----------------------------------------" << endl;
}

// ============================================= END OF GRAPHICS.CPP =============================================

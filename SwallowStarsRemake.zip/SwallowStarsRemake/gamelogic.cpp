#define WIN32_LEAN_AND_MEAN
#include <iostream>
#include <conio.h>
#include <windows.h>
#include <fstream>

#include "configload.h"
#include "gamelogic.h"
#include "graphics.h"
#include "main.h"

using namespace std;

// ============================================= VARIABLES BELOW =============================================

#define MAX_NUMBER_OF_STARS 20
#define MAX_NUMBER_OF_HUNTERS 10

// STAR VARIABLES - - - - - - - - - - - - - - -
int starsX[MAX_NUMBER_OF_STARS] = {};
int starsY[MAX_NUMBER_OF_STARS] = {};
int starsSpeed[MAX_NUMBER_OF_STARS] = {};

// HUNTER VARIABLES - - - - - - - - - - - - - -
int huntersX[MAX_NUMBER_OF_HUNTERS] = {};
int huntersY[MAX_NUMBER_OF_HUNTERS] = {};
int huntersSpeed[MAX_NUMBER_OF_HUNTERS] = {};
int huntersHeight[MAX_NUMBER_OF_HUNTERS] = {};
int huntersWidth[MAX_NUMBER_OF_HUNTERS] = {};
int huntersBounces[MAX_NUMBER_OF_HUNTERS] = {};
int huntersDirectionsX[MAX_NUMBER_OF_HUNTERS] = {};
int huntersDirectionsY[MAX_NUMBER_OF_HUNTERS] = {};

// DIFFICULTY-DEPENDANT VARIABLES - - - - - - -

int hunterBouncesBase = 0;

double starSpawnRateNow;
double hunterSpawnRateNow;

double starSpawnRateBase;
double hunterSpawnRateBase;

double starSpawnRateMax;
double hunterSpawnRateMax;

int damageDecline; // damage decline setting -> can be 0 (off) or 1 (on)
// damage decline makes it so that Hunters deal more damage when the Player is on low health
int declineStart; // the moment the decline starts working

void applyDifficulty(int difficulty) { // these are instead of this function so the difficulty can be properly assigned
    switch(difficulty) {
        case 1: { // EASY
            starSpawnRateMax = starSpawnRateBase + 0.4; // + 40% by the end
            hunterSpawnRateMax = hunterSpawnRateBase + 0.1;
            starSpeedMax = 2;
            damageDecline = 0;
            hunterBouncesBase = 0;
            break;
        }
        case 2: { // MEDIUM
            starSpawnRateMax = starSpawnRateBase + 0.2; // + 20% by the end
            hunterSpawnRateMax = hunterSpawnRateBase + 0.2;
            damageDecline = 1;
            declineStart = 80;
            hunterBouncesBase = 1;
            break;
        }
        case 3: { // HARD
            starSpawnRateMax = starSpawnRateBase + 0.1; // + 10% by the end
            hunterSpawnRateMax = hunterSpawnRateBase + 0.4;
            damageDecline = 1;
            declineStart = 50;
            hunterBouncesBase = 2;
            break;
        }
    }
    starSpawnRateNow = starSpawnRateBase;
    hunterSpawnRateNow = hunterSpawnRateBase;
}

// ============================================= GAME LOGIC FUNCTIONS BELOW =============================================

void updateDifficultyRates() { // so that game gets progressively harder as it goes
    double progress = 0.0;
    double t = (double)timer;
    double T = (double)timeLeft;

    if (T > 0.0) {
        progress = t / T;
    }

    if (progress < 0.0) {
        progress = 0.0;
    }
    if (progress > 1.0) {
        progress = 1.0;
    }

    // starSpawnRateNow = base + progress * (max - base)
    starSpawnRateNow = starSpawnRateBase + (progress * (starSpawnRateMax - starSpawnRateBase));
    if (starSpawnRateNow > starSpawnRateMax) {
        starSpawnRateNow = starSpawnRateMax;
    }
    // hunterSpawnRateNow = base + progress * (max - base)
    hunterSpawnRateNow = hunterSpawnRateBase + (progress * (hunterSpawnRateMax - hunterSpawnRateBase));
    if (hunterSpawnRateNow > hunterSpawnRateMax) {
        hunterSpawnRateNow = hunterSpawnRateMax;
    }

    if (progress >= 0.5) {
        hunterBouncesBase = hunterBouncesBase + ((progress-0.4)*10); // np. przy progress = 0.7 i hunterBouncesBase = 1 -> hunterbouncesbase = 1 + (0.3 * 10) = 1 + 3
    }
}

// ---------------------------------------- STARS ----------------------------------------

void spawnStars() { // only one star can get created at a time , same for hunters
    if ((double)rand() / RAND_MAX < starSpawnRateNow) { // star gets created
        int starSpawnLocation = (rand() % BoardSizeX)+1;
        int starSpeed = (rand() % 3)+1; // 1-3
        for (int i = 0; i < MAX_NUMBER_OF_STARS; i++) {
            if (starsX[i] == 0) { // this means this position in list is currently not occupied
                starsX[i] = starSpawnLocation;
                starsY[i] = 1;
                starsSpeed[i] = starSpeed;
                break;
            }
        }
    }
}

void moveStars() {
    for (int i = MAX_NUMBER_OF_STARS - 1; i >= 0; i--) {
        starsY[i] = starsY[i] + starsSpeed[i];
        if (starsY[i] > BoardSizeY) {
            starsX[i] = 0;
            starsY[i] = 0;
            starsSpeed[i] = 0;
        }
    }
}

void checkIfStarCaught() {
    for (int i = MAX_NUMBER_OF_STARS - 1; i >= 0; i--) {
        if (starsX[i] == Px && starsY[i] <= Py && starsY[i] + starsSpeed[i] >= Py) {
            starsCaught++;
            starsX[i] = 0;
            starsY[i] = 0;
            starsSpeed[i] = 0;
        }
    }
}

// ---------------------------------------- HUNTERS ----------------------------------------

void spawnHunters() {
    if ((double)rand() / RAND_MAX < hunterSpawnRateNow) { // hunter gets created

        int hunterSpeed = (rand() % 3) + 1; // 1-3

        // which border of the screen does the hunter appear in
        int side = rand() % 4; // 0-3
        int hx, hy;

        switch (side) {
            case 0: hx = 1; hy = (rand() % (BoardSizeY - 2)) + 1; break; // left
            case 1: hx = BoardSizeX; hy = (rand() % (BoardSizeY - 2)) + 1; break; // right
            case 2: hx = (rand() % (BoardSizeX - 2)) + 1; hy = 1; break; // top
            case 3: hx = (rand() % (BoardSizeX - 2)) + 1; hy = BoardSizeY; break; // bottom
        }

        // hunter shape
        int shapeX = (rand() % hunterMaxWidth) + 1;
        int shapeY = (rand() % hunterMaxHeight) + 1;
        if (shapeX == 1 && shapeY == 1) {
            if (rand() % 2) shapeX++; else shapeY++;
        }

        // direction toward the player
        int dx = (Px > hx) - (Px < hx);
        int dy = (Py > hy) - (Py < hy);

        int hunterBounces = hunterBouncesBase + (rand() % 4) + 1; // base + 1-4

        for (int i = 0; i < MAX_NUMBER_OF_HUNTERS; i++) {
            if (huntersX[i] == 0) { // this means this position in list is currently not occupied
                huntersX[i] = hx;
                huntersY[i] = hy;
                huntersSpeed[i] = hunterSpeed;
                huntersWidth[i] = shapeX;
                huntersHeight[i] = shapeY;
                huntersDirectionsX[i] = dx;
                huntersDirectionsY[i] = dy;
                huntersBounces[i] = hunterBounces;
                break;
            }
        }
    }
}

void moveHunters() {
    for (int i = MAX_NUMBER_OF_HUNTERS - 1; i >= 0; i--) {
        huntersX[i] += huntersDirectionsX[i] * huntersSpeed[i];
        huntersY[i] += huntersDirectionsY[i] * huntersSpeed[i];

        // perfect bouncing = multiplying the movement vector by "-1" on axis that hit the wall
        // when hitting a wall:
        // vertical wall → dx *= -1  (flip horizontal movement)
        // horizontal wall → dy *= -1 (flip vertical movement)

        bool bounced = false;

        int w = huntersWidth[i];
        int h = huntersHeight[i];

        // CHECK IF TOUCHING WALL
        if (huntersX[i] < 1) {
            huntersX[i] = 1;
            huntersDirectionsX[i] *= -1;
            bounced = true;
        }
        else if (huntersX[i] + w - 1 > BoardSizeX) {
            huntersX[i] = BoardSizeX - (w - 1);
            huntersDirectionsX[i] *= -1;
            bounced = true;
        }
        // separate X and Y so the corners don't get confusing
        if (huntersY[i] < 1) {
            huntersY[i] = 1;
            huntersDirectionsY[i] *= -1;
            bounced = true;
        }
        else if (huntersY[i] + h - 1 > BoardSizeY) {
            huntersY[i] = BoardSizeY - (h - 1);
            huntersDirectionsY[i] *= -1;
            bounced = true;
        }

        if (bounced) {
            huntersBounces[i]--;
            if (huntersBounces[i] <= 0) {
                huntersX[i] = 0;
                huntersY[i] = 0;
                huntersSpeed[i] = 0;
                huntersWidth[i] = 0;
                huntersHeight[i] = 0;
                huntersDirectionsX[i] = 0;
                huntersDirectionsY[i] = 0;
                huntersBounces[i] = 0;
                continue;
            }
        }
    }
}

void checkHunterCollisions() {
    for (int i = 0; i < MAX_NUMBER_OF_HUNTERS; i++) {

        int hx = huntersX[i];
        int hy = huntersY[i];
        int w  = huntersWidth[i];
        int h  = huntersHeight[i];

        bool overlap = (Px >= hx && Px <= hx + w - 1) && (Py >= hy && Py <= hy + h - 1);

        if (overlap) {
            if (damageDecline && playerLifeForce <= declineStart) {
                playerLifeForce -= (huntersSpeed[i]*2);
            }
            else {
                playerLifeForce -= huntersSpeed[i];
            }
            if (playerLifeForce < 0) playerLifeForce = 0;
            break;
        }
    }
}

// ---------------------------------------- BOARD ----------------------------------------

void printBoard(){    // print current board function
    for ( int y = 0; y <= BoardSizeY+1; y++ ) {
        for ( int x = 0; x <= BoardSizeX+1; x++) { // FIRST PRINT THE BOARD AND STATUS AREA
            setColor(8);
            if (y == 0 || y == BoardSizeY+1) { // top or bottom
                if (x==0 || x==BoardSizeX+1) { // left or right corner
                    cout << "o";
                }
                else cout << "-";
                continue;
            }
            if (x==0) {
                cout << "|";
                continue;
            }
            if (x==BoardSizeX+1) {
                cout << "|                                      ";
                continue;
            }
            if (x==Px && y==Py) {
                if (playerLifeForce>10) {
                    setColor(11);
                }
                else if (playerLifeForce <= 10 && playerLifeForce > 5)
                    setColor(14);
                else setColor(4);
                if (swallowFrame%4==0) {
                    cout << "v";
                }
                else if (swallowFrame%4==1) {
                    cout << "-";
                }
                else if (swallowFrame%4==2) {
                    cout << "^";
                }
                else {
                    cout << "-";
                }
                continue;
            }

            // PRINT STARS AND HUNTERS

            bool drewSomethingHere = false;

            for (int i = 0; i < MAX_NUMBER_OF_HUNTERS; i++) {
                int hx = huntersX[i];
                int hy = huntersY[i];
                int hlen = huntersWidth[i];
                int hh = huntersHeight[i];

                if (x >= hx && x < hx + hlen && y >= hy && y < hy + hh) {
                    if (huntersSpeed[i] == 1) {
                        setColor(13);
                    }
                    else if (huntersSpeed[i] == 2) {
                        setColor(9);
                    }
                    if (huntersSpeed[i] == 3) {
                        setColor(12);
                    }
                    cout << "#";
                    drewSomethingHere = true;
                    break;
                }
            }

            if (drewSomethingHere) {
                continue; // skips star loop if hunter drawn (hunters go OVER the stars)
            }

            for (int i = 0; i < MAX_NUMBER_OF_STARS; i++) {
                if (starsX[i] == x && starsY[i] == y) {
                    setColor(6);
                    cout << "*";
                    drewSomethingHere = true;
                    break;
                }
            }

            if (!drewSomethingHere)
                cout << " ";
        }
        cout << endl;
    }
    cout << endl;
    swallowFrame++;
}
// ---------------------------------------- SCORES ----------------------------------------
    const int MAX_SCORES = 100;
    int scores[MAX_SCORES];
    int scoreCount = 0;
// ------------------------------------------------------------- SAVING THE SCORE TO A FILE

void saveScore(int score) {
    std::ofstream out("scores.txt", std::ios::app); // save final score to scores.txt
    if (out.is_open()) {
        out << score << '\n';
    }
    out.close();

    std::ifstream in("scores.txt");
    while (in >> scores[scoreCount] && scoreCount < MAX_SCORES) {
        scoreCount++;
    }
    in.close();
}
// ----------------------------------------------------------- FURTHER SCORE MANAGEMENT

// ------------------------ read best score at end of game in addition to current score

int findBestScore() {
    int bestScore = 0;
    for (int i = 0; i < scoreCount; i++) {
        if (scores[i] > bestScore) {
            bestScore = scores[i];
        }
    }
    return bestScore;
}

// ============================================= END OF GAMELOGIC.CPP =============================================

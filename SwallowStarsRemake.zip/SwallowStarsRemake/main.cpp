using namespace std;
#define WIN32_LEAN_AND_MEAN
#include <iostream>
#include <conio.h>
#include <cstdlib>
#include <cstdio>
#include <windows.h>

// headers - inclusion of other files
#include "configload.h"
#include "gamelogic.h"
#include "graphics.h"
#include "main.h"

// ============================================= GLOBAL VARIABLES =============================================

int Px, Py; // player position on the X and Y axis
int BoardSizeX, BoardSizeY;
int currentSpeed, minSpeed, maxSpeed;
int timer = 0, timeLeft;
int difficulty;

// STARS AND HUNTERS - - - - - - - - - - - - - - - - - - - - - - - - -

int starsToCatch;
int starsCaught = 0;
int starSpeedMax;

// other  - - - - - - - - - - - - - - - - - - - - - - - - -

int playerLifeForce; // health points of Player
int swallowFrame = 0; // for 0 print "v" , for 1 print "-" , for 2 print "^" for 3 print "-" and keep cycling
char lastMovementMade = 's'; // for constant swallow motion
int level = 1;

int hunterMaxWidth, hunterMaxHeight;

// ============================================= MAIN =============================================

int main() {

    loadConfig("config.txt");

    Px = BoardSizeX/2;
    Py = BoardSizeY-1; // player STARTING coordinates

    if (minSpeed <= 0) {
        minSpeed = 1;
    }

    currentSpeed = minSpeed;

    srand(time(NULL)); // srand() returns random number , while time(null) gives current time in seconds -> so this "seed" will always be different

    char action = 0; // always initialized

    applyDifficulty(difficulty);

    hideCursor();
    startingScreen();
    printBoard();
    printStatus();

    while (true) {
        updateDifficultyRates();
        moveCursorToTop();

        // ---------------------------------------- PLAYER MOVEMENT ----------------------------------------
        action = 0;
        if (kbhit()) {
            action = getch();
        }

        if (action == 'w' || action == 's' || action == 'a' || action == 'd') {
            lastMovementMade = action; // detect which direction the player will move to
        }
        else if (action == 'o' && currentSpeed > minSpeed) {
            currentSpeed--;
        }
        else if (action == 'p' && currentSpeed < maxSpeed) {
            currentSpeed++;
        }

        switch (lastMovementMade) {
            case 'w':
                Py = max(1, Py - currentSpeed);
                break;
            case 's':
                Py = min(BoardSizeY, Py + currentSpeed);
                break;
            case 'a':
                Px = max(1, Px - currentSpeed);
                break;
            case 'd':
                Px = min(BoardSizeX, Px + currentSpeed);
                break;
        }

        // ---------------------------------------- GAME LOGIC ----------------------------------------
        spawnStars();
        moveStars();
        checkIfStarCaught();

        spawnHunters();
        moveHunters();
        checkHunterCollisions();

        timer++;

        printBoard();
        printStatus();

        Sleep(100); // delay

        if (playerLifeForce == 0 || timer >= timeLeft || starsCaught >= starsToCatch) {
            break;
        }
    }
    // ---------------------------------------- END OF GAME ----------------------------------------
    int finalScore = ((timeLeft - timer) * (playerLifeForce + starsCaught)) * difficulty;

    saveScore(finalScore);
    endingScreen();
    findBestScore();

    return 0;
}
// ============================================= END OF MAIN.CPP =============================================

#ifndef CONFIGLOAD_H
#define CONFIGLOAD_H

void trim(char* str);
void loadConfig(const char* filename);

#endif // CONFIGLOAD_H

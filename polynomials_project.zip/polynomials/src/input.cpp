#include "input.h"
#include <iostream>
using namespace std;

bool isValidPolynomial(const string& poly) {
    for (char c : poly) {
        if (!(c == 'x' || c == '+' || c == '-' || c == '*' ||
              c == '^' || (c >= '0' && c <= '9'))) {
            return false;
        }
    }
    return !poly.empty();
}

string readPolynomialFromConsole() {
    string input;
    while (true) {
        cout << "Enter a polynomial in x (example: x^2-2*x-1):\n";
        getline(cin, input);

        string cleaned = "";
        for (char c : input) if (c != ' ')
            cleaned += c;

        if (isValidPolynomial(cleaned))
            return cleaned;

        cout << "Invalid polynomial. Try again.\n";
    }
}

#pragma once
#include <string>

// global strings used by functions in numerous cpp files

extern std::string polynomial;
extern std::string polynomial_rewritten;

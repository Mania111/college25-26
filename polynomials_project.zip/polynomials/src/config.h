#pragma once

// this acts like a "config.txt" file, except I did it as a header instead so I could learn how to do that.

#define BOARDSIZE_X 20
#define BOARDSIZE_Y 10
#define MAX_SAVED 5 // number of graphs the user can keep saved at a time

#define COLOR_GRAPH 12 // bright red
#define COLOR_AXIS 7 // grey

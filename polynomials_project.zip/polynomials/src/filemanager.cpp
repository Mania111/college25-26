// this file is responsible for accessing the saved graphs, loading them and saving new ones

#include "filemanager.h"
#include "globals.h"
#include "polynomial.h"
#include "config.h"
#include <fstream>
#include <iostream>
using namespace std;

int loadSavedPolynomials(SavedPolynomial list[]) {
    ifstream file("polynomials.txt");
    if (!file.is_open()) return 0;

    int count = 0; string line;
    while (getline(file, line) && count < MAX_SAVED) {
        size_t sep = line.find('|');
        if (sep == string::npos) continue;

        list[count].name = line.substr(0, sep);
        list[count].polynomial = line.substr(sep + 1);
        count++;
    }
    file.close();
    return count;
}

void deletePolynomialFromFile(int index) {
    SavedPolynomial list[MAX_SAVED];
    int count = loadSavedPolynomials(list);
    if (index < 0 || index >= count) { cout << "Invalid index.\n"; return; }

    for (int i = index; i < count - 1; i++) list[i] = list[i + 1];
    count--;

    ofstream file("polynomials.txt");
    for (int i = 0; i < count; i++) file << list[i].name << "|" << list[i].polynomial << endl;
    file.close();
}

void savePolynomialToFile(const string& name, const string& poly) {
    ofstream file("polynomials.txt", ios::app);
    file << name << "|" << poly << endl;
    file.close();
}

void loadGraphMenu() {
    SavedPolynomial list[MAX_SAVED];
    int count = loadSavedPolynomials(list);
    if (count == 0) { cout << "No saved polynomials.\n"; return; } // no saved polynomials in polynomials.txt

    cout << "\nSaved polynomials:\n";
    for (int i = 0; i < count; i++) cout << i + 1 << ". " << list[i].name << endl; // this prints out the list elements if there are any

    cout << "Select number (0 to cancel): ";
    int choice; cin >> choice; cin.ignore();
    if (choice == 0) return;
    if (choice < 1 || choice > count) { cout << "Invalid selection.\n"; return; } // out of bounds

    cout << "1. Load\n2. Delete\nChoose action: "; // choose whether to load a saved graph or to delete it
    int action; cin >> action; cin.ignore();

    if (action == 1) { // load
        polynomial = list[choice - 1].polynomial;
        polynomialAnalysis();
        analyzePolynomial();
        printBoard();
    } else if (action == 2) {
        deletePolynomialFromFile(choice - 1); // deletes it.
        cout << "Polynomial deleted.\n";
    } else {
        cout << "Invalid action.\n";
    }
}

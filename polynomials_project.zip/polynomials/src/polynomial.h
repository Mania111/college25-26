#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H

#include <string>

// Global polynomial variables
extern std::string polynomial;
extern std::string polynomial_rewritten;

// Function declarations
std::string readPolynomialFromConsole();
std::string polynomialAnalysis();
int f(int x);
int printBoard();
void analyzePolynomial();

#endif

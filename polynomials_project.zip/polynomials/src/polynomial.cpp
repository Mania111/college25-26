// this code is responsible for going through the polynomial to change its structure so it can be used in board printing later
// is also checks its properties

#include "polynomial.h"
#include "globals.h"
#include "config.h"
#include "input.h"
#include <iostream>
using namespace std;

// Expands expressions like x^3 into x*x*x for easier evaluation later
string polynomialAnalysis() {
    string result = "";
    for (int i = 0; i < polynomial.length(); i++) {
        if (polynomial[i] == 'x' && i + 2 < polynomial.length() && polynomial[i + 1] == '^') {
            int power = polynomial[i + 2] - '0';
            for (int j = 0; j < power; j++) {
                result += "x";
                if (j < power - 1)
                    result += "*";
            }
            i += 2; // skip ^ and power digit
        }
        else {
            result += polynomial[i];
        }
    }
    polynomial_rewritten = result;
    return result;
}

// Evaluates polynomial_rewritten at integer x value, e.g. f(2) for x=2
int f(int x) {
    int result = 0;
    int sign = 1; // Tracks + or - sign of term
    int i = 0;
    while (i < polynomial_rewritten.length()) {
        if (polynomial_rewritten[i] == '+') {
            sign = 1;
            i++;
        }
        else if (polynomial_rewritten[i] == '-') {
            sign = -1;
            i++;
        }
        int term = 1;
        // Parses one term consisting of numbers, x's and multiplications
        while (i < polynomial_rewritten.length() && polynomial_rewritten[i] != '+' && polynomial_rewritten[i] != '-') {
            if (polynomial_rewritten[i] == 'x') {
                term *= x; // Substitute x with value
                i++;
            }
            else if (polynomial_rewritten[i] >= '0' && polynomial_rewritten[i] <= '9') {
                term *= (polynomial_rewritten[i] - '0');
                i++;
            }
            else if (polynomial_rewritten[i] == '*') {
                i++; // Skip '*'
            }
        }
        result += sign * term;
    }
    return result;
}

// Counts terms separated by + or -
int countTerms(const string& poly) {
    int terms = 0; bool inTerm = false;
    for (char c : poly) {
        if ((c >= '0' && c <= '9') || c == 'x') {
            if (!inTerm) { terms++; inTerm = true; }
        } else if (c == '+' || c == '-') { inTerm = false; }
    }
    return terms;
}

// Finds polynomial degree by counting consecutive x's in terms
int findDegree(const string& poly) {
    int maxDegree = 0, currentDegree = 0;
    for (char c : poly) {
        if (c == 'x') { currentDegree++; if (currentDegree > maxDegree) maxDegree = currentDegree; }
        else if (c == '+' || c == '-') currentDegree = 0;
    }
    return maxDegree;
}

// Returns the sign of the leading coefficient
string leadingCoefficientSign(const string& poly) {
    for (char c : poly) {
        if (c == '-') return "negative";
        if ((c >= '0' && c <= '9') || c == 'x') return "positive";
    }
    return "unknown";
}

// printing all found properties
void analyzePolynomial() {
    cout << "\nPolynomial properties: -----------------\n";
    int terms = countTerms(polynomial_rewritten);
    int degree = findDegree(polynomial_rewritten);

    if (terms == 1) cout << "- Type: monomial\n";
    else if (terms == 2) cout << "- Type: binomial\n";
    else if (terms == 3) cout << "- Type: trinomial\n";
    else cout << "- Type: polynomial (" << terms << " terms)\n";

    cout << "- Degree: " << degree << " (";
    if (degree == 0) cout << "constant";
    else if (degree == 1) cout << "linear";
    else if (degree == 2) cout << "quadratic";
    else if (degree == 3) cout << "cubic";
    else cout << "higher-degree";
    cout << ")\n";

    cout << "- Leading coefficient: " << leadingCoefficientSign(polynomial_rewritten) << "\n";
}

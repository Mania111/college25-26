#pragma once
#include <string>

bool isValidPolynomial(const std::string& poly); // checks if input by user is valid
std::string readPolynomialFromConsole(); // reads the input

#pragma once
#include <string>

struct SavedPolynomial {
    std::string name;
    std::string polynomial;
};

int loadSavedPolynomials(SavedPolynomial list[]);
void deletePolynomialFromFile(int index);
void loadGraphMenu();
void savePolynomialToFile(const std::string& name, const std::string& poly);

#include "globals.h"

std::string polynomial = "";
std::string polynomial_rewritten = "";

// this is for board printing

#include "board.h"
#include "polynomial.h"
#include "config.h"
#include <iostream>
using namespace std;

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE); // windows console handle for colors

void setColor(int color) {
    SetConsoleTextAttribute(hConsole, color);
}

int printBoard() {
    for (int cordY = BOARDSIZE_Y; cordY >= -BOARDSIZE_Y; cordY--) {
        for (int cordX = -BOARDSIZE_X; cordX <= BOARDSIZE_X; cordX++) {
            if (f(cordX) == cordY) {
                setColor(COLOR_GRAPH);    // Use color from config.h
                cout << "*";
                setColor(COLOR_AXIS);     // Reset to axis color
            }
            else if (cordX == 0 && cordY == 0) {
                setColor(COLOR_AXIS);
                cout << "+";
            }
            else if (cordX == 0) {
                setColor(COLOR_AXIS);
                cout << "|";
            }
            else if (cordY == 0) {
                setColor(COLOR_AXIS);
                cout << "-";
            }
            else {
                setColor(COLOR_BACKGROUND);
                cout << " ";
            }
            if (cordX == BOARDSIZE_X) cout << endl;
        }
    }
    setColor(COLOR_AXIS);  // Reset color at the end just in case
    return 0;
}

// this is the code responsible for generating the program in console
// it generates the user interface and lets user choose what action to take

#include <iostream>
#include "globals.h"
#include "polynomial.h"
#include "filemanager.h"
#include "input.h"
#include "config.h"
#include "board.h"
using namespace std;


int mainMenu() {
    cout << "\n=== Polynomial Grapher ===\n";
    cout << "1. Make a new graph\n2. Load a graph from file\n0. Exit\nChoose option: ";
    int choice; cin >> choice; cin.ignore(); // reads user input
    return choice;
}

int main() {
    while (true) {
        int choice = mainMenu();

        if (choice == 1) {
            polynomial = readPolynomialFromConsole();
            polynomialAnalysis();
            analyzePolynomial();
            printBoard();

            cout << "Save polynomial? (y/n): "; // asks if generated polynomial is meant to be saved
            char c; cin >> c; cin.ignore();
            if (c == 'y' || c == 'Y') {
                cout << "Enter name: "; // lets the user name the saved polynomial so it can be found later
                string name; getline(cin, name);
                if (name.empty()) name = polynomial; // if no name put, name it after the function itself
                savePolynomialToFile(name, polynomial);
            }

        } else if (choice == 2) {
            loadGraphMenu();
        } else if (choice == 0) break;
        else cout << "Invalid option.\n";
    }
    return 0;
}

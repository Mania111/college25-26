#pragma once
#include <windows.h>  // Needed for HANDLE, color functions

// Sets console text color
void setColor(int color);

// Prints the polynomial graph board
int printBoard();
